import argparse

from ultralytics import YOLO


def parse_args():
    parser = argparse.ArgumentParser(description="Validate a trained YOLO-meniscus checkpoint.")
    parser.add_argument("--weights", required=True, help="Path to best.pt or another trained checkpoint.")
    parser.add_argument("--data", required=True, help="Path to a YOLO data.yaml file.")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--device", default="0")
    parser.add_argument("--split", default="val", choices=["val", "test"])
    parser.add_argument("--project", default="runs_yolo_meniscus_val")
    parser.add_argument("--name", default="validation")
    return parser.parse_args()


def main():
    args = parse_args()
    model = YOLO(args.weights)
    model.val(
        data=args.data,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        split=args.split,
        project=args.project,
        name=args.name,
        plots=True,
    )


if __name__ == "__main__":
    main()
