import argparse
from pathlib import Path

from ultralytics import YOLO


ROOT = Path(__file__).resolve().parent


def parse_args():
    parser = argparse.ArgumentParser(description="Train YOLO-meniscus with PP-LCNet, MSSimAM, and Shape-IoU.")
    parser.add_argument("--data", required=True, help="Path to a YOLO data.yaml file.")
    parser.add_argument("--model", default=str(ROOT / "yaml" / "yolov11_lcnet_mssimam.yaml"))
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--optimizer", default="SGD")
    parser.add_argument("--device", default="0")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--project", default="runs_yolo_meniscus")
    parser.add_argument("--name", default="yolo_meniscus")
    parser.add_argument("--no-pretrained", action="store_true", help="Disable pretrained initialization.")
    return parser.parse_args()


def main():
    args = parse_args()
    model = YOLO(args.model)
    model.train(
        data=args.data,
        epochs=args.epochs,
        batch=args.batch,
        imgsz=args.imgsz,
        optimizer=args.optimizer,
        device=args.device,
        workers=args.workers,
        seed=args.seed,
        project=args.project,
        name=args.name,
        patience=args.epochs,
        pretrained=not args.no_pretrained,
        plots=True,
        shapeiou=True,
    )


if __name__ == "__main__":
    main()
