# YOLO-meniscus

Source code for the YOLO-meniscus object detection model used for meniscus tear detection and injury grading on knee MRI images.

This public version keeps the final model components only:

- PP-LCNet backbone via `timm` using `lcnet_075`
- Multi-scale SimAM attention module (`MSSimAM`)
- Enhanced Shape-IoU bounding-box regression branch

Datasets, training outputs, reviewer rerun queues, ablation-only configurations, and trained checkpoints are not included.

## Repository Layout

```text
.
├── ultralytics/                         # Modified Ultralytics source
├── yaml/yolov11_lcnet_mssimam.yaml       # Final YOLO-meniscus model
├── data_template.yaml                    # Example YOLO data config
├── train_yolo_meniscus.py                # Training entry point
├── validate_yolo_meniscus.py             # Validation/test entry point
└── requirements.txt
```

## Main Code Locations

- `ultralytics/nn/modules/block.py`: `MSSimAM`
- `ultralytics/nn/tasks.py`: `timm.create_model()` integration for `lcnet_075`
- `ultralytics/utils/metrics.py`: enhanced `ShapeIoU` branch in `bbox_iou()`
- `ultralytics/utils/loss.py`: `shapeiou=True` routing into `BboxLoss`

## Installation

Create a Python environment, then install dependencies:

```bash
pip install -r requirements.txt
```

For GPU training, install a PyTorch build matching your CUDA version before running the command above if needed.

## Data Format

Use the standard YOLO detection format:

```text
dataset/
├── train/images
├── train/labels
├── val/images
├── val/labels
├── test/images
└── test/labels
```

Each label file should contain rows in YOLO format:

```text
class_id x_center y_center width height
```

Create a project-specific data YAML by copying `data_template.yaml` and editing `path`, `nc`, and `names`.

## Training

```bash
python train_yolo_meniscus.py --data /absolute/path/to/data.yaml --epochs 100 --batch 64 --imgsz 640 --device 0
```

The training script uses the final model YAML and enables `shapeiou=True` by default.

## Validation Or Independent Testing

```bash
python validate_yolo_meniscus.py --weights runs_yolo_meniscus/yolo_meniscus/weights/best.pt --data /absolute/path/to/data.yaml --split test --device 0
```

Use `--split val` for validation-set evaluation and `--split test` for independent test-set evaluation when a test split is available.

## Notes

This codebase is derived from Ultralytics YOLO and retains the original AGPL-3.0 license headers in the source files.
